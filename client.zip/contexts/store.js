/** 
 * zustand store
 * 전역 상태 관리를 해봅시다.
 */

/** library */
import create from 'zustand'

const useStore = create((set) => ({

  }));
  
export default useStore;