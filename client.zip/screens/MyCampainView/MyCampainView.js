// 진행중 캠패인 화면

import { StyleSheet, Text, View, TouchableOpacity, Dimensions,FlatList } from 'react-native';
import React, { useState } from 'react';
import { AntDesign } from '@expo/vector-icons'; 
import { MaterialCommunityIcons } from '@expo/vector-icons'; 
import { FontAwesome } from '@expo/vector-icons';
import { ScrollView } from 'react-native-gesture-handler';

import GridLayout from './GridLayout';
import Button from './Button';

const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;

const MyCampainView = ({ navigation }) => {

  const [items, setItems] = useState([
    { id: '1', name: 'Item 1' },
    { id: '2', name: 'Item 2' },
    { id: '3', name: 'Item 3' },
    { id: '4', name: 'Item 4' },
    { id: '5', name: 'Item 5' },
  ]);

  const renderItem = ({ item }) => (
    <View style={styles.item}>
      <Text style={styles.title}>{item.name}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity 
          onPress={() => { navigation.reset({ routes: [{ name: 'Home_Screen' }] }) }}>
          <AntDesign name="closecircleo" size={30} color="black" />
        </TouchableOpacity>
      </View>

      <View style={styles.footer}>
        <View style={styles.case2}>
        <Button title="예정" color="black" back="#FFDE9D" onPress={() => setRoomNum(0)}/>
        </View>
        <View >
        <Button title="예정" color="black" back="#FFDE9D" onPress={() => setRoomNum(1)}/>
        </View>


            
      </View>
      

      <View style={styles.container}>
        <FlatList
          data={items}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}/>
      </View>
      
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: 50,
    backgroundColor: '#FFFFFF',
    
  },
  item: {
    backgroundColor: '#FFF1D7',
    padding: 20,
    marginVertical: 8,
    marginHorizontal: 16,
    shadowColor: "#A01900", 
    shadowOpacity: 0.1,
    shadowOffset: { width: 3, height: 3 }, 
    elevation: 9,
    borderRadius:20,
  },
  title: {
    fontSize: 32,
  },
  header: {
    height: 60,
    backgroundColor: '#ffffff',
    alignItems: 'flex-end',
    justifyContent: 'center',
    
  },
  title: {
    color: '#000',
    fontSize: 24,
    fontWeight: 'bold',
  },
  text: {
    fontSize: 16,
    color: '#000',
  },
  footer: {
    flexDirection: "row",
    alignItems: 'stretch',
    justifyContent: 'center',
    backgroundColor: "#ffffff",
    height : 80,
  }, 
  case1: {
    flex: 1,   
  },
  case2: {
    marginRight: 35,
  }

});

export default MyCampainView;