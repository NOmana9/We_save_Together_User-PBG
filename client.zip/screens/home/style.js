import { StyleSheet } from "react-native";

const styles = StyleSheet.create({
    container :{
        //배경 색
        backgroundColor: "#fff",
        flex: 1, 
        alignItems: 'center', 
        justifyContent: 'center', 
        paddingBottom: 150,
    },
    title: {
        //폰트 사이즈
        fontSize:30,
        //두께
        fontWeight:"700",
    },
    drawer:{
        //폰트 사이즈
        fontSize:20,
        //두께
        fontWeight:"700",
        //윗 공간 간격
        marginTop:30,
        // 왼쪽 공간 이격
        marginLeft:280,
        flex: 1,
    },
    iconbutton: {
        margin: 10,
      },
    box1: {
        flex:1,
        width:50,
        height:50,
        
    }

})

export default styles