
import { Pressable, Text,View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";


import styles from "./style";
export default function HomeScreen({ navigation }) {
    return (
        <SafeAreaView>
            <Text>홈 화면</Text>
            <View style={styles.Edit}>
                <Pressable 
                onPress={() => { navigation.reset({ routes: [{ name: 'MyInfo_Screen' }] }) }} 
                style={styles.signIn_pressable}>
                    <Text style={styles.signIn}>내정보</Text>
                </Pressable>
            </View>

            <View style={styles.Edit}>
                <Pressable 
                onPress={() => { navigation.reset({ routes: [{ name: 'Information_Screen' }] }) }} 
                style={styles.signIn_pressable}>
                    <Text style={styles.signIn}>설명 사항</Text>
                </Pressable>
            </View>

            <View style={styles.Edit}>
                <Pressable 
                onPress={() => { navigation.reset({ routes: [{ name: 'MycampainView_Screen' }] }) }} 
                style={styles.signIn_pressable}>
                    <Text style={styles.signIn}>내 캠패인 조회</Text>
                </Pressable>
            </View>


        </SafeAreaView>
    )
}